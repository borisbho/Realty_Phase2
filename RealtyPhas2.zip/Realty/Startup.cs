﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin;
using Owin;
using Realty.Models;

[assembly: OwinStartupAttribute(typeof(Realty.Startup))]
namespace Realty
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);

            ApplicationDbContext context = new ApplicationDbContext();
            var RoleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(context));
            var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));


            
            if (!RoleManager.RoleExists("User"))
            {
                var roleU = new IdentityRole();
                roleU.Name = "User";
                RoleManager.Create(roleU);

            }

            if (!RoleManager.RoleExists("Admin"))
            {
                var role = new IdentityRole();
                role.Name = "Admin";
                RoleManager.Create(role);
                

                var user = new ApplicationUser();
                user.UserName = "Admin";
                user.Email = "admin@test.com";

                string userPWD = "Boris123!";

                var chkUser = UserManager.Create(user, userPWD);

                if (chkUser.Succeeded)
                {
                    var result = UserManager.AddToRole(user.Id, "Admin");
                }
            }

            var newUser = new ApplicationUser();
            newUser.UserName = "admin@admin.com";
            newUser.Email = "admin@admin.com";

            string password = "Boris123!";

            var ckUser = UserManager.Create(newUser, password);

            if (ckUser.Succeeded)
            {
                var result = UserManager.AddToRole(newUser.Id, "Admin");
            }


            var oldUser = new ApplicationUser();
            oldUser.UserName = "user@user.com";
            oldUser.Email = "user@user.com";

            string oldPassword = "Boris123!";

            var ckOldUser = UserManager.Create(oldUser, oldPassword);

            if (ckOldUser.Succeeded)
            {
                var result = UserManager.AddToRole(newUser.Id, "User");
            }




        }
    }
}
