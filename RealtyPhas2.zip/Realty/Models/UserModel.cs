﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Realty.Models
{
    public class UserModel
    {
        public ApplicationUser User { get; set; }
        public string UserRole { get; set; } = "";
    }
}