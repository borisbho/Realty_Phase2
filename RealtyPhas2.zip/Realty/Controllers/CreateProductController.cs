﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HomesDAL;
using HomesLib.Model;

namespace Realty.Controllers
{
    [Authorize(Roles = "Admin")]

    public class CreateProductController : Controller
    {
        // GET: CreateProduct
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(HomesModel hm)
        {
            Random rand = new Random();
       

            using (var db = new HomesEntities())
            {
                var query = db.HomeTables.Select(x => x);
               
                var homes = query.ToList();
                //int id = (int)db.HomeTables.Select(x => x.HomeID).Last();
                var newHome = new HomeTable()
                {
                    HomeID = rand.Next(10, 100),
                    StreetAddress = hm.StreetAddress,
                    City = hm.City,
                    State = hm.State,
                    Zip = hm.Zip,
                    HomeInfo = hm.HomeInfo,
                    Price = hm.Price,
                    HomeDetailOne = hm.HomeDetailOne,
                    HomeDetailTwo = hm.HomeDetailTwo,
                    HomeDetailThree = hm.HomeDetailThree,
                    Image = hm.Image

                };
                db.HomeTables.Add(newHome);
                db.SaveChanges();



            }
            return View();

        }

    }
}





