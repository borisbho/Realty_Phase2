﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HomesDAL;
using HomesLib.Service;
using HomesLib.Model;
using Microsoft.AspNet.Identity;

namespace Realty.Controllers
{
    public class CartController : Controller
    {
        IHomesService service = new HomesService();

        // GET: Cart 
        public RedirectToRouteResult AddToCart(int homeId,string returnUrl)
        {
            
            var user = User.Identity.GetUserId();
            service.AddCartItem(user,homeId, 1);
            return RedirectToAction("Index", new { returnUrl });
        }
        public RedirectToRouteResult RemoveCart(int homeId, string returnUrl)
        {
            service.RemoveFromCart(homeId);
            return RedirectToAction("Index", new { returnUrl });
        }
        public RedirectToRouteResult AddOne(int homeId, string returnUrl)
        {
            service.AddOneToCart(homeId);
            return RedirectToAction("Index", new { returnUrl });

        }
        public ViewResult Index(string returnUrl)

        {

              return View(service.GetCart());
        } 
        private AspNetUser GetUser()
        {
            AspNetUser user = (AspNetUser)Session["AspNetUser"];
            return user;
        }
        public PartialViewResult Summary()
        {
            return PartialView(service.GetCart());
        }
        public ActionResult Checkout()
        {
             return View(service.GetCart());
        }
 
    }

}
