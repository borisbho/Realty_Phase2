﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HomesLib.Model;
using HomesDAL;
using HomesLib.Service;
using Microsoft.AspNet.Identity;
namespace Realty.Controllers
{
      public class RealtyController : Controller
    {
        IHomesService service = new HomesService();
        // GET: Realty
        [HttpGet]
        public ActionResult Index()
        {

            ViewBag.OnHomeDetailPage = false;
            HomesListModel model = service.GetAllHomes();
            return View(model);
        }
        [HttpPost]
        public ActionResult SearchHome(string SearchString)
        {
            ViewBag.OnHomeDetailPage = true;
            //HomesListModel model = service.GetHomeBySearch(SearchString);
            return View(service.GetHomeBySearch(SearchString)); 
        }
        public ActionResult HomeDetail(int id)
        {
            ViewBag.OnHomeDetailPage = true;
            HomesModel model = service.GetHomeById(id);
            return View(model);
        }
        [Authorize(Roles = "Admin")]

        public ActionResult DeleteHome(int id)
        {
            using (var db = new HomesEntities())
            {
                var query = db.HomeTables.Select(x => x);
                var goblins = query.ToList();
                var houseToRemove = db.HomeTables.Where(x => x.HomeID == id).First();

                db.HomeTables.Remove(houseToRemove);
                db.SaveChanges();

            }
            
            return View();

        }
        [Authorize(Roles = "Admin")]

        [HttpGet]
        public ActionResult EditHome(int id)
        {
            var home = service.GetHomeById(id);
            return View(home);
        }
        [HttpPost]
        public ActionResult EditHome(int id, HomesModel hm)
        {
            using (var db = new HomesEntities())
            {
                var query = db.HomeTables.Select(x => x);
                var homes = query.ToList();

                var homeToUpDate = db.HomeTables.Where(x => x.HomeID == id).First();
                homeToUpDate.StreetAddress = hm.StreetAddress;
                homeToUpDate.City = hm.City;
                homeToUpDate.State = hm.State;
                homeToUpDate.Zip = hm.Zip;
                homeToUpDate.HomeInfo = hm.HomeInfo;
                homeToUpDate.Price = hm.Price;
                homeToUpDate.HomeDetailOne = hm.HomeDetailOne;
                homeToUpDate.HomeDetailTwo = hm.HomeDetailTwo;
                homeToUpDate.HomeDetailThree = hm.HomeDetailThree;
                

                db.SaveChanges();
            }
            return View("DeleteHome");
        }
        public ActionResult Clear()
        {
            service.RemoveAllFromCart(User.Identity.GetUserId());
            return View("Index");
        }

    }
}